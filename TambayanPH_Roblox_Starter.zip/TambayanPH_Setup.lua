-- TAMBAYAN PH - Lightweight Roblox Hangout Starter
-- Paste this entire script into Roblox Studio's Command Bar and run it.

local Workspace = game:GetService("Workspace")
local Lighting = game:GetService("Lighting")

local old = Workspace:FindFirstChild("TambayanPH")
if old then old:Destroy() end

local root = Instance.new("Folder")
root.Name = "TambayanPH"
root.Parent = Workspace

local function part(name, size, cf, material, color, parent)
    local p = Instance.new("Part")
    p.Name = name
    p.Size = size
    p.CFrame = cf
    p.Anchored = true
    p.Material = material or Enum.Material.SmoothPlastic
    p.Color = color or Color3.fromRGB(150,150,150)
    p.TopSurface = Enum.SurfaceType.Smooth
    p.BottomSurface = Enum.SurfaceType.Smooth
    p.Parent = parent or root
    return p
end

local function label(text, position, parent)
    local anchor = part("SignAnchor", Vector3.new(0.2,0.2,0.2),
        CFrame.new(position), Enum.Material.SmoothPlastic, Color3.new(1,1,1), parent)
    anchor.Transparency = 1
    anchor.CanCollide = false

    local gui = Instance.new("BillboardGui")
    gui.Size = UDim2.fromOffset(240, 60)
    gui.StudsOffset = Vector3.new(0, 2.5, 0)
    gui.AlwaysOnTop = true
    gui.Parent = anchor

    local t = Instance.new("TextLabel")
    t.Size = UDim2.fromScale(1,1)
    t.BackgroundTransparency = 1
    t.Text = text
    t.TextScaled = true
    t.Font = Enum.Font.GothamBold
    t.TextColor3 = Color3.new(1,1,1)
    t.TextStrokeTransparency = 0.35
    t.Parent = gui
end

-- Ground
part("Ground", Vector3.new(180,1,180), CFrame.new(0,-0.5,0),
    Enum.Material.Grass, Color3.fromRGB(75,130,70))

-- Main plaza
part("Plaza", Vector3.new(70,0.5,55), CFrame.new(0,0,0),
    Enum.Material.Concrete, Color3.fromRGB(145,145,145))

-- Roads
part("Road_NorthSouth", Vector3.new(18,0.2,180), CFrame.new(0,0.1,0),
    Enum.Material.Asphalt, Color3.fromRGB(45,45,45))
part("Road_EastWest", Vector3.new(180,0.2,18), CFrame.new(0,0.11,0),
    Enum.Material.Asphalt, Color3.fromRGB(45,45,45))

-- Beach
part("Beach", Vector3.new(65,0.4,35), CFrame.new(55,0.1,65),
    Enum.Material.Sand, Color3.fromRGB(220,195,135))
part("Water", Vector3.new(65,0.5,40), CFrame.new(55,-0.1,102),
    Enum.Material.Water, Color3.fromRGB(65,150,190))

-- Sari-sari store
local store = Instance.new("Model")
store.Name = "SariSariStore"
store.Parent = root
part("Store", Vector3.new(18,8,12), CFrame.new(-42,4,30),
    Enum.Material.Wood, Color3.fromRGB(125,85,55), store)
part("Counter", Vector3.new(16,3,2), CFrame.new(-42,2,23.5),
    Enum.Material.Wood, Color3.fromRGB(95,60,40), store)
label("SARI-SARI STORE", Vector3.new(-42,8,30), store)

-- Tambayan hut
local hut = Instance.new("Model")
hut.Name = "TambayanHut"
hut.Parent = root
part("Floor", Vector3.new(24,1,18), CFrame.new(35,1,30),
    Enum.Material.Wood, Color3.fromRGB(145,100,60), hut)
part("Roof", Vector3.new(27,1,21), CFrame.new(35,10,30),
    Enum.Material.Wood, Color3.fromRGB(105,65,40), hut)
for _,x in ipairs({25,45}) do
    for _,z in ipairs({23,37}) do
        part("Post", Vector3.new(1,9,1), CFrame.new(x,5,z),
            Enum.Material.Wood, Color3.fromRGB(105,65,40), hut)
    end
end
label("TAMBAYAN", Vector3.new(35,11,30), hut)

-- Benches
for i, z in ipairs({-18, -8, 8, 18}) do
    part("Bench", Vector3.new(10,1,2), CFrame.new(30,1.5,z),
        Enum.Material.Wood, Color3.fromRGB(120,75,45))
    part("BenchBack", Vector3.new(10,3,1), CFrame.new(30,3,z+0.8),
        Enum.Material.Wood, Color3.fromRGB(120,75,45))
end

-- Therapy / quiet corner
local quiet = Instance.new("Model")
quiet.Name = "QuietCorner"
quiet.Parent = root
part("Platform", Vector3.new(25,0.6,20), CFrame.new(-45,0.4,-35),
    Enum.Material.Wood, Color3.fromRGB(155,120,85), quiet)
label("QUIET CORNER • TALK • REST", Vector3.new(-45,3,-35), quiet)

-- Simple trees
local function tree(x,z)
    local m = Instance.new("Model")
    m.Name = "Tree"
    m.Parent = root
    part("Trunk", Vector3.new(2,9,2), CFrame.new(x,4.5,z),
        Enum.Material.Wood, Color3.fromRGB(95,65,40), m)
    local crown = part("Leaves", Vector3.new(9,9,9), CFrame.new(x,10,z),
        Enum.Material.Grass, Color3.fromRGB(55,125,60), m)
    crown.Shape = Enum.PartType.Ball
end

for _,pos in ipairs({
    {-70,-65},{70,-65},{-70,65},{15,70},{-15,70},{78,30},{-78,30}
}) do
    tree(pos[1],pos[2])
end

-- Welcome sign
label("WELCOME TO TAMBAYAN PH 🇵🇭", Vector3.new(0,4,24), root)

-- Lighting: simple and mobile-friendly
Lighting.ClockTime = 17.5
Lighting.Brightness = 2
Lighting.GlobalShadows = false
Lighting.EnvironmentDiffuseScale = 0.5
Lighting.EnvironmentSpecularScale = 0.2

print("Tambayan PH created successfully!")
