TAMBAYAN PH - Roblox Hangout Starter

This package contains a Roblox Studio Lua setup script.
Import/use it in Roblox Studio to generate a lightweight Filipino hangout starter map.

HOW TO USE
1. Open Roblox Studio and create/open your game.
2. Open View > Command Bar.
3. Paste the contents of `TambayanPH_Setup.lua` into the Command Bar.
4. Press Enter.
5. A folder named `TambayanPH` will be created in Workspace.

The map is intentionally simple/low-poly for better performance on mobile devices.
